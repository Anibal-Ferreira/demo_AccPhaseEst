%
% estimatePHASE_DFT_rect.m
%
% This code replicates the plots in Fig. 5 of the following manuscript submitted to Signals:
%
% Marco Oliveira, Vasco Santos, Andre Saraiva and Anibal Ferreira
% Demystifying DFT-based harmonic phase estimation, transformation, and synthesis
% https://www.preprints.org/manuscript/202409.0098/v1
%
% This code shows the cumulative phase estimation error as a function of the fractional frequency ???l,
% when the DFT and the Rectangular window are used under two SNR conditions
%
% When using this file for educational, research or development purposes, please give credit to
% the manuscript indicated above, including the Preprint link.
%
% E-mail contact:  ajf(at)fe.up.pt
% September 2024
%



format short e

N=128; N2=N/2;
ell=13.0;
infinitesimo = 0.01;

n=[0:N-1];
direxp = exp(-1i*pi*[0:N-1]/N);

hsinwin=sin(pi/N*([0:N-1]+0.5)); % Sine window
hrecwin=rectwin(N).'; % Rectangular window

A=1; SNR=30;
sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation

accdata=[]; accdelta=[]; % run 100 iterations to average noise effects
for delta=(-0.50+infinitesimo):0.01:(0.50-infinitesimo)
    omega=2*pi*(ell+delta)/N;
    accphi=[]; difphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
        x=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=x+noise; x=x.*hrecwin; X=fft(x);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi+pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi/2+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        error = abs(exp(1j*phiCENTER)-exp(1j*estphiCENTER));
        accphi = [accphi phi];
        difphi = [difphi error];
    end
    accdata = [accdata sum(abs(difphi))/length(difphi)];
    accdelta = [accdelta delta];
end
subplot(1,2,1)
plot(accdelta, accdata)
xlabel('$\Delta_{\ell}$', 'interpreter', 'latex', 'fontsize',14)
ylabel('ERROR')
title('DFT-RECT, SNR=30 dB')
    

A=1; SNR=10;
sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation

accdata=[]; accdelta=[]; % run 100 iterations to average noise effects
for delta=(-0.50+infinitesimo):0.01:(0.50-infinitesimo)
    omega=2*pi*(ell+delta)/N;
    accphi=[]; difphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
        x=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=x+noise; x=x.*hrecwin; X=fft(x);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi+pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi/2+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        error = abs(exp(1j*phiCENTER)-exp(1j*estphiCENTER));
        accphi = [accphi phi];
        difphi = [difphi error];
    end
    accdata = [accdata sum(abs(difphi))/length(difphi)];
    accdelta = [accdelta delta];
end
subplot(1,2,2)
plot(accdelta, accdata)
xlabel('$\Delta_{\ell}$', 'interpreter', 'latex', 'fontsize',14)
title('DFT-RECT, SNR=10 dB')



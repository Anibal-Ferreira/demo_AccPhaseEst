%
% CRLBphivar.m
%
% This code replicates the plots in Fig. 10 and 11 of the following published paper (MDPI-Signals):
%
% Marco Oliveira, Vasco Santos, Andre Saraiva and Anibal Ferreira
% Demystifying DFT-based harmonic phase estimation, transformation, and synthesis
% URL = {https://www.mdpi.com/2624-6120/5/4/46}
% DOI = {10.3390/signals5040046}
%
% This code computes the mean and variance of the phase estimation error under different SNR
% conditions, different time analysis windows, different transforms, and when DeltaEll takes on two
% extreme values depending on the estimator. The Cramer-Rao lower bound is taken as a reference.
%
% When using this file for educational, research or development purposes, please give credit to
% the paper indicated above, including the DOI link.
%
% E-mail contact:  ajf(at)fe.up.pt
% December 2024
%


disp('Please be patient, this will take a while....');

format short e

N=128; N2=N/2;
infinitesimo = 0.01;

n=[0:N-1];
% auxiliary vector for ODFT computation
direxp = exp(-1i*pi*[0:N-1]/N);

hsinwin=sin(pi/N*([0:N-1]+0.5)); % Sine window
hrecwin=rectwin(N).'; % Rectangular window
hhanwin=0.5*(1-cos(2*pi*(0.5+n)/N)); % Hanning window

A=1;
ell=13.0; delta = 0.01; % delta = 0.01
omega=2*pi*(ell+delta)/N;

accSNR=[]; varphi=[]; avgphi=[]; CRLB=[]; % run 100 iterations to average noise effects
for SNR=0:2.5:30
    accSNR = [accSNR SNR];
    sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation
    CRLB=[CRLB 2*sigmanoise^2/(N*A^2)];
    
    accerrphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
      xclean=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        
      for niter=1:100
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=xclean+noise; x=x.*hsinwin;
        X = x.*direxp;  % this is sub-optimal ODFT computation !
        X=fft(X);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi + pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi*(1-1/(2*N))+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        ABS1=abs(phiCENTER-estphiCENTER);
        ABS2=abs(phiCENTER-estphiCENTER+2*pi);
        ABS3=abs(phiCENTER-estphiCENTER-2*pi);
        if (ABS1<ABS2)
            if (ABS1<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        else
            if (ABS2<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER+2*pi)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        end
      end
    end
    varphi=[varphi var(accerrphi)];
    avgphi=[avgphi mean(accerrphi)];
end

figure(1)
semilogy(accSNR,CRLB)
hold on
semilogy(accSNR,varphi,'-^')
hold off
ylabel('$\mbox{var}\{\phi-\hat{\phi}\}$', 'interpreter', 'latex', 'fontsize',14)
xlabel('SNR')

figure(2)
plot(accSNR,zeros(size(CRLB)),'--')
hold on
plot(accSNR,avgphi,'-^')
hold off
ylabel('$\mbox{mean}\{\phi-\hat{\phi}\}$', 'interpreter', 'latex', 'fontsize',14)
xlabel('SNR')


% now delta = 0.5
delta = 0.5;
omega=2*pi*(ell+delta)/N;

accSNR=[]; varphi=[]; avgphi=[]; CRLB=[]; % run 100 iterations to average noise effects
for SNR=0:2.5:30
    accSNR = [accSNR SNR];
    sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation
    CRLB=[CRLB 2*sigmanoise^2/(N*A^2)];
    
    accerrphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
      xclean=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        
      for niter=1:100
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=xclean+noise; x=x.*hsinwin;
        X = x.*direxp;  % this is sub-optimal ODFT computation !
        X=fft(X);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi + pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi*(1-1/(2*N))+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        ABS1=abs(phiCENTER-estphiCENTER);
        ABS2=abs(phiCENTER-estphiCENTER+2*pi);
        ABS3=abs(phiCENTER-estphiCENTER-2*pi);
        if (ABS1<ABS2)
            if (ABS1<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        else
            if (ABS2<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER+2*pi)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        end
      end
    end
    varphi=[varphi var(accerrphi)];
    avgphi=[avgphi mean(accerrphi)];
end


figure(1)
hold on
semilogy(accSNR,varphi,'-*')
hold off

figure(2)
hold on
plot(accSNR,avgphi,'-*')
hold off



% now find phase estimation error variance for the RECT window

delta = -0.50+0.01; % delta = 0.01 - 0.5 since the Delta range is different
omega=2*pi*(ell+delta)/N;

accSNR=[]; varphi=[]; avgphi=[]; CRLB=[]; % run 100 iterations to average noise effects
for SNR=0:2.5:30
    accSNR = [accSNR SNR];
    sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation
    CRLB=[CRLB 2*sigmanoise^2/(N*A^2)];
    
    accerrphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
      xclean=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        
      for niter=1:100
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=xclean+noise; x=x.*hrecwin;
        X=fft(x);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi + pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi/2+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        ABS1=abs(phiCENTER-estphiCENTER);
        ABS2=abs(phiCENTER-estphiCENTER+2*pi);
        ABS3=abs(phiCENTER-estphiCENTER-2*pi);
        if (ABS1<ABS2)
            if (ABS1<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        else
            if (ABS2<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER+2*pi)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        end
      end
    end
    varphi=[varphi var(accerrphi)];
    avgphi=[avgphi mean(accerrphi)];
end

figure(1)
hold on
semilogy(accSNR,varphi,'-o')
hold off

figure(2)
hold on
plot(accSNR,avgphi,'-o')
hold off

% now delta = 0.5 -0.5 since the Delta range now is different 
delta = -0.50 + 0.5;
omega=2*pi*(ell+delta)/N;

accSNR=[]; varphi=[]; avgphi=[]; CRLB=[]; % run 100 iterations to average noise effects
for SNR=0:2.5:30
    accSNR = [accSNR SNR];
    sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation
    CRLB=[CRLB 2*sigmanoise^2/(N*A^2)];
    
    accerrphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
      xclean=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        
      for niter=1:100
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=xclean+noise; x=x.*hrecwin;
        X=fft(x);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi + pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi/2+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        ABS1=abs(phiCENTER-estphiCENTER);
        ABS2=abs(phiCENTER-estphiCENTER+2*pi);
        ABS3=abs(phiCENTER-estphiCENTER-2*pi);
        if (ABS1<ABS2)
            if (ABS1<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        else
            if (ABS2<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER+2*pi)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        end
      end
    end
    varphi=[varphi var(accerrphi)];
    avgphi=[avgphi mean(accerrphi)];
end

figure(1)
hold on
semilogy(accSNR,varphi,'-s')
hold off

figure(2)
hold on
plot(accSNR,avgphi,'-s')
hold off




% now find phase estimation error variance for the HANN window and ODFT

delta = 0.01; % delta = 0.01
omega=2*pi*(ell+delta)/N;

accSNR=[]; varphi=[]; avgphi=[]; CRLB=[]; % run 100 iterations to average noise effects
for SNR=0:2.5:30
    accSNR = [accSNR SNR];
    sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation
    CRLB=[CRLB 2*sigmanoise^2/(N*A^2)];
    
    accerrphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
      xclean=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        
      for niter=1:100
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=xclean+noise; x=x.*hhanwin;
        X = x.*direxp;  % this is sub-optimal ODFT computation !
        X=fft(X);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi + pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi*(1-1/(2*N))+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        ABS1=abs(phiCENTER-estphiCENTER);
        ABS2=abs(phiCENTER-estphiCENTER+2*pi);
        ABS3=abs(phiCENTER-estphiCENTER-2*pi);
        if (ABS1<ABS2)
            if (ABS1<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        else
            if (ABS2<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER+2*pi)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        end
      end
    end
    varphi=[varphi var(accerrphi)];
    avgphi=[avgphi mean(accerrphi)];
end

figure(1)
hold on
semilogy(accSNR,varphi,'-v')
hold off

figure(2)
hold on
plot(accSNR,avgphi,'-v')
hold off


% now delta = 0.5
delta = 0.5;
omega=2*pi*(ell+delta)/N;

accSNR=[]; varphi=[]; avgphi=[]; CRLB=[]; % run 100 iterations to average noise effects
for SNR=0:2.5:30
    accSNR = [accSNR SNR];
    sigmanoise=sqrt(A^2/(2*10^(SNR/10))); % standard deviation
    CRLB=[CRLB 2*sigmanoise^2/(N*A^2)];
    
    accerrphi=[];
    for phi=-(pi-pi/100):pi/100:(pi-pi/100)
      xclean=A*sin(n*omega+phi); %  power is A^2/2 ~ sum(x.^2)/N
        
      for niter=1:100
        noise=sigmanoise*randn(1,N); % power is sum(noise.^2)/N
%         10*log10(var(x)/var(noise))  % = 10*log10((x*x.')/(noise*noise.')) % check SNR
        x=xclean+noise; x=x.*hhanwin;
        X = x.*direxp;  % this is sub-optimal ODFT computation !
        X=fft(X);
        [value estell]=max(abs(X(1:N2)));
        if (estell==1 || estell==N2+1 || estell==N2+2 || estell==N)
            disp('No sinusoids found');
            return;
        end
        phiCENTER = phi + pi*(ell+delta)*(1-1/N);
        phiCENTER = mod(phiCENTER+pi,2*pi)-pi; % get principal value
        estphiCENTER=angle(X(estell))+pi*(1-1/(2*N))+pi*(estell-1)*(1-1/N); % (ell-1) because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        ABS1=abs(phiCENTER-estphiCENTER);
        ABS2=abs(phiCENTER-estphiCENTER+2*pi);
        ABS3=abs(phiCENTER-estphiCENTER-2*pi);
        if (ABS1<ABS2)
            if (ABS1<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        else
            if (ABS2<ABS3)
                accerrphi = [accerrphi (phiCENTER-estphiCENTER+2*pi)];
            else
                accerrphi = [accerrphi (phiCENTER-estphiCENTER-2*pi)];
            end
        end
      end
    end
    varphi=[varphi var(accerrphi)];
    avgphi=[avgphi mean(accerrphi)];
end


figure(1)
hold on
semilogy(accSNR,varphi,'-+')
hold off
axis([0 30 5E-6 3E-2])

figure(2)
hold on
plot(accSNR,avgphi,'-+')
hold off


figure(1)
legend('CRLB', 'ODFT-SINE \Delta=0.01', 'ODFT-SINE \Delta=0.5', ' DFT-RECT \Delta=-0.49', ' DFT-RECT\Delta=0.0', 'ODFT-HANN \Delta=0.01', 'ODFT-HANN \Delta=0.5')

figure(2)
legend('ideal', 'ODFT-SINE \Delta=0.01', 'ODFT-SINE \Delta=0.5', ' DFT-RECT \Delta=-0.49', ' DFT-RECT\Delta=0.0', 'ODFT-HANN \Delta=0.01', 'ODFT-HANN \Delta=0.5')

disp('Done!')
disp('Please note that for multiple runs of the code, as noise conditions change, Fig. 2 will be different, but not Fig. 1') 
%
% gerawav_v4.m
%
% This code allows replicating the plots in Fig. 15, 16, 17, and 18 of the following published paper (MDPI-Signals):
%
% Marco Oliveira, Vasco Santos, Andre Saraiva and Anibal Ferreira
% Demystifying DFT-based harmonic phase estimation, transformation, and synthesis
% URL = {https://www.mdpi.com/2624-6120/5/4/46}
% DOI = {10.3390/signals5040046}
%
% This code displays an overlay of magnitude spectra and unwrapped NRD vectors extracted from
% a sawtooth signal that is FM modulated and subject to different SNR conditions
%
% When using this file for educational, research or development purposes, please give credit to
% the paper indicated above, including the DOI link.
%
% E-mail contact:  ajf(at)fe.up.pt
% December 2024
%



close all
clear all

A=1; N=1024; N2=N/2; FS=22050;
hsin = sin(pi*([0:N-1]+0.5)/N); % sine window
direxp = exp(-1i*pi*[0:N-1]/N); % auxiliary sequence for ODFT computation


% set noise level relative to the magnitude of the fundamental
SNR = 30.0;
Psignal=1/(2*pi^2)*sum(1./([1:20].^2)); % Power of sawtooth wave (20 harmonics) 
sigma=sqrt(Psignal)/(10^(SNR/20)); % standard variation of the noise


% signal duration in seconds
M=floor(1.00*FS); % one second of signal, M is number of samples
m=[1:M-1];        % avoid zero to prevent divide-by-zero problems
t=m/FS;           % time index

% PITCH frequeny (in Hertz), this is between male and female typical pitch values
PITCH=150;

% deviation around the mean PITCH value
FM=0.25; % 2.5 % in Hertz
ft=PITCH*t+1/(2*pi)*sin(2*pi*FM*t); % = OMEGA t / (2PI)
% now find derivative
dft=PITCH+FM*cos(2*pi*FM*t);

% synthesize SAWtooth wave
nh=20; % nh is number of harmonics

x=sin(2*pi*ft)/(pi); % fundamental frequency term
for k=2:nh
   x=x+sin(k*2*pi*ft)/(pi*k); % harmonic coefficients decay at 1/(k*pi)
end

noise=sigma*randn(M-1,1).'; % synthesize noise

x=x+noise; % add noise
x=x/max(abs(x))*0.5; % normalize magnitude

figure(1)
plot(([80:960]-80)*1000/FS, x(80:960))
axis([0 40 -0.6 0.6])
xlabel('TIME (ms)')
ylabel('AMPLITUDE')
figtitle = strcat({'SNR='},num2str(SNR),{'dB, FM='},num2str(FM),{'Hz'});
title(figtitle)


figure(2)
subplot(2,1,1);
title(figtitle)
for k=1:512:length(x)-1023 % short-time ODFT with 50% overlap
    frame = x(k:k+1023);
    frame = frame .* hsin;
    frame = frame .* direxp;  % this is sub-optimal ODFT computation !
    H = 20*log10(abs(fft(frame)));
    hold on
    plot([0:164]*FS/N, H(1:165))
    hold off
end
axis([0 3500 -05 40]);
xlabel('FREQUENCY (Hz)')
ylabel('PSD (dB)')



% NOW extract NRD taking into consideration the previous
% knowledge of the fundamental frequency at the center
% of each frame
figure(2)
for k=1:512:length(x)-1023 % short-time DFT with 50% overlap
    frame = x(k:k+1023);
    frame = frame .* hsin;
    frame = frame .* direxp;  % this is sub-optimal ODFT computation !
    H = fft(frame);
    absH = abs(H);
    
    % we know the ground truth average fundamental frequency at the center of each frame
    % in a real situation, a pitch estimator needs to be used here
    FundFreq = 0.5*(dft(k+511)+dft(k+512))/(FS/N); % F0 (in ODFT bins) at the center of the frame
    
    % for all harmonics find (wrapped) NRD
    for nharm=1:20
        searchmin = 1+ floor(nharm*FundFreq+0.5)-3; % 1+ is because of MATLAB indexing
        searchmax = 1+ floor(nharm*FundFreq+0.5)+3; % 1+ is because of MATLAB indexing
        [magpeak pospeak] = max(absH(searchmin:searchmax)); % find local maximum
        pospeak = pospeak + searchmin-1; % restore absolute coordinates
        % estimate phase of each harmonic at the frame center (see paper/book details on this)
        estphiCENTER = angle(H(pospeak))+pi*(1-1/(2*N))+pi*(pospeak-1)*(1-1/N); % (pospeak-1) is because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        NRDwrap(nharm) = estphiCENTER; % just copy for further processing
    end
    % now compute wrapped NRD for all harmonics except the fundamental
    for nharm=2:20
        NRDwrap(nharm) = (NRDwrap(nharm) - nharm * NRDwrap(1));
        NRDwrap(nharm) = mod(NRDwrap(nharm)+pi,2*pi)-pi; % get principal value
    end
    NRDwrap(1)=0; % by definition, NRD[1]=0
    % now unwrap and normalize NRD
    NRD = (unwrap(NRDwrap))/(2*pi); % normalize by (2PI)
    subplot(2,1,2)
    hold on
    plot(NRD)
    hold off
%     pause
end
    xlabel('HARMONIC INDEX')
    ylabel('UNWRAPPED NRD')
    axis([0 20 -1 1])





% synthesize derivative of SAWtooth wave
y=cos(2*pi*ft);
for k=2:nh
   y=y+cos(k*2*pi*ft);
end
y=y.*dft/PITCH; % multiply by frequency and normalize by average PITCH
Psignal=20/2; % Power of derivative of sawtooth wave (20 harmonics) 
sigma=sqrt(Psignal)/(10^(SNR/20)); % standard variation of the noise
noise=sigma*randn(M-1,1).'; % synthesize noise
y=y+noise; % add noise
y=y/max(abs(y))*0.5;

figure(3)
plot(([80:960]-80)*1000/FS, y(80:960))
axis([0 40 -0.2 0.6])
xlabel('TIME (ms)')
ylabel('AMPLITUDE')
title(figtitle)



figure(4)
subplot(2,1,1);
title(figtitle)
for k=1:512:length(y)-1023 % short-time ODFT with 50% overlap
    frame = -y(k:k+1023);
    frame = frame .* hsin;
    frame = frame .* direxp;  % this is sub-optimal ODFT computation !
    H = 20*log10(abs(fft(frame)));
    hold on
    plot([0:164]*FS/N, H(1:165))
    hold off
end
xlabel('FREQUENCY (Hz)')
ylabel('PSD (dB)')
axis([0 3500 -15 20]);
% axis([0 1 -85 15]);



% NOW extract NRD taking into consideration the previous
% knowledge of the fundamental frequency at the center
% of each frame
figure(4)
for k=1:512:length(y)-1023 % short-time DFT with 50% overlap
    frame = -y(k:k+1023);
    frame = frame .* hsin;
    frame = frame .* direxp;  % this is sub-optimal ODFT computation !
    H = fft(frame);
    absH = abs(H);
    
    % we know the ground truth average fundamental frequency at the center of each frame
    % in a real situation, a pitch estimator needs to be used here
    FundFreq = 0.5*(dft(k+511)+dft(k+512))/(FS/N); % F0 (in ODFT bins) at the center of the frame
    
    % for all harmonics find (wrapped) NRD
    for nharm=1:20
        searchmin = 1+ floor(nharm*FundFreq+0.5)-3; % 1+ is because of MATLAB indexing
        searchmax = 1+ floor(nharm*FundFreq+0.5)+3; % 1+ is because of MATLAB indexing
        [magpeak pospeak] = max(absH(searchmin:searchmax)); % find local maximum
        pospeak = pospeak + searchmin-1; % restore absolute coordinates
        % estimate phase of each harmonic at the frame center (see paper/book details on this)
        estphiCENTER = angle(H(pospeak))+pi*(1-1/(2*N))+pi*(pospeak-1)*(1-1/N); % (pospeak-1) is because of MATLAB indexing
        estphiCENTER = mod(estphiCENTER+pi,2*pi)-pi; % get principal value
        NRDwrap(nharm) = estphiCENTER; % just copy for further processing
    end
    % now compute wrapped NRD for all harmonics except the fundamental
    for nharm=2:20
        NRDwrap(nharm) = (NRDwrap(nharm) - nharm * NRDwrap(1));
        NRDwrap(nharm) = mod(NRDwrap(nharm)+pi,2*pi)-pi; % get principal value
    end
    NRDwrap(1)=0; % by definition, NRD[1]=0
    % now unwrap and normalize NRD
    NRD = (unwrap(NRDwrap))/(2*pi); % normalize by (2PI)
    subplot(2,1,2)
    hold on
    plot(NRD)
    hold off
%     pause
end
    xlabel('HARMONIC INDEX')
    ylabel('UNWRAPPED NRD')
    axis([0 20 0 5.2])

    
